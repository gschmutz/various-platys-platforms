Add configurations of repositorieswhich should be executed upon initialisation of the graphdb database. This will only be done once, in the init phase of the database.

dbpedia/
├── config.ttl
├── fts-m2-index.sparql
└── toLoad

Check: https://github.com/khaller93/graphdb-free